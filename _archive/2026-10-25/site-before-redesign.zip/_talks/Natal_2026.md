---
title: "Approximating fixed size quantum correlations in polynomial time"
collection: talks
type: "Contributed talk"
excerpt: "Polynomial-time additive approximations of fixed-size quantum correlations via Bose-symmetric de Finetti theorems."
category: talk
permalink: /talks/Natal_2026
venue: "Quantum at the Dunes, International Institute of Physics (IIP-UFRN)"
date: 2026-03-05
location: "Natal, Brazil"
lat: -5.8400
lon: -35.1978
---

[More information here](https://www.iip.ufrn.br/en/events/quantum-at-the-dunes)

**Abstract.** We show that ε-additive approximations of the optimal value of fixed-size two-player free games with fixed-dimensional entanglement assistance can be computed in time poly(1/ε). This stands in contrast to previous analytic approaches, which focused on scaling with the number of questions and answers, but yielded only strict exp(1/ε) guarantees. Our main result is based on novel Bose-symmetric quantum de Finetti theorems tailored for constrained quantum separability problems. These results give rise to semidefinite programming (SDP) outer hierarchies for approximating the entangled value of such games. By employing representation-theoretic symmetry reduction techniques, we demonstrate that these SDPs can be formulated and solved with computational complexity poly(1/ε), thereby enabling efficient ε-additive approximations. In addition, we introduce a measurement-based rounding scheme that translates the resulting outer bounds into certifiably good inner sequences of entangled strategies. These strategies can, for instance, serve as warm starts for see-saw optimization methods. We believe that our techniques are of independent interest for broader classes of constrained separability problems in quantum information theory.

[Paper (arXiv)](https://arxiv.org/abs/2507.12302)
